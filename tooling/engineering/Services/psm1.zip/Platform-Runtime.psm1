# ============================================================================
# JustDefenders ©
#
# Platform-Runtime.psm1
#
# WP-PLATFORM-001 PR-009
# Production Platform Integration Runtime
#
# Purpose:
#   Top-level composition module for the JustDefenders Operational Platform.
#
# Responsibilities:
#   • Import Engineering Common
#   • Import Operational Service Host
#   • Import Harvester Runtime
#   • Load Platform private components
#   • Load Platform public components
#   • Export the Platform API
#
# ============================================================================

Set-StrictMode -Version Latest

$ErrorActionPreference = 'Stop'

# ============================================================================
# Module Initialisation
# ============================================================================

Set-StrictMode -Version Latest

$ErrorActionPreference = 'Stop'

# ============================================================================
# Resolve Module Paths
# ============================================================================

$ModuleRoot = Split-Path `
    -Parent `
    $PSCommandPath

$PrivateRoot = Join-Path `
    $ModuleRoot `
    'Private'

$PublicRoot = Join-Path `
    $ModuleRoot `
    'Public'

# ============================================================================
# Import Runtime Dependencies
# ============================================================================

Import-Module `
    (Join-Path $ModuleRoot '..\Common\Engineering-Common.psm1') `
    -Force `
    -ErrorAction Stop

Import-Module `
    (Join-Path $ModuleRoot 'Operational-ServiceHost.psm1') `
    -Force `
    -ErrorAction Stop

Import-Module `
    (Join-Path $ModuleRoot 'Harvester-Runtime.psm1') `
    -Force `
    -ErrorAction Stop

# ============================================================================
# Platform Runtime Manifest
# ============================================================================

$script:PlatformManifest = [ordered]@{

    Private = @(
        'Platform-Bootstrap.ps1'
        'Platform-Lifecycle.ps1'
        'Platform-Diagnostics.ps1'
    )

    Public = @(
    'Start-JDPlatform.ps1'
    'Platform-Control.ps1'
    'Get-JDPlatformStatus.PR004.ps1'
)

    RequiredModules = @(
        'Engineering-Common'
        'Operational-ServiceHost'
        'Harvester-Runtime'
    )

}

# ============================================================================
# Runtime Loader
# ============================================================================

function Import-JDPlatformScriptCollection {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('Private','Public')]
        [string]$Collection,

        [Parameter(Mandatory)]
        [string]$Root
    )

    foreach ($ScriptName in $script:PlatformManifest[$Collection]) {

        $ScriptPath = Join-Path `
            $Root `
            $ScriptName

        if (-not (Test-Path $ScriptPath)) {

            throw "Platform runtime failed to locate $Collection script: $ScriptName"

        }

        . $ScriptPath

    }

}

# ============================================================================
# Load Private Runtime
# ============================================================================

Import-JDPlatformScriptCollection `
    -Collection Private `
    -Root $PrivateRoot

# ============================================================================
# Load Public Runtime
# ============================================================================

Import-JDPlatformScriptCollection `
    -Collection Public `
    -Root $PublicRoot

# ============================================================================
# Runtime Validation
# ============================================================================

$RequiredFunctions = @(

    'Initialize-JDPlatform'

    'Start-JDPlatform'

    'Stop-JDPlatform'

    'Restart-JDPlatform'

    'Get-JDPlatformStatus'

)

foreach ($FunctionName in $RequiredFunctions) {

    if (-not (Get-Command `
                -Name $FunctionName `
                -ErrorAction SilentlyContinue)) {

        throw "Platform Runtime validation failed. Missing function: $FunctionName"

    }

}

# ============================================================================
# Platform Metadata
# ============================================================================

$script:PlatformRuntimeMetadata = [ordered]@{

    Name          = 'JustDefenders Platform Runtime'

    Version       = '1.0.0'

    Loaded        = Get-Date

    PrivateFiles  = $script:PlatformManifest.Private.Count

    PublicFiles   = $script:PlatformManifest.Public.Count

    HostRuntime   = 'Operational-ServiceHost'

    Harvester     = 'Harvester-Runtime'

}

function Get-JDPlatformMetadata {

    [CmdletBinding()]
    param()

    return [PSCustomObject]$script:PlatformRuntimeMetadata

}

# ============================================================================
# Export Public API
# ============================================================================

Export-ModuleMember `
    -Function @(
        'Initialize-JDPlatform',
        'Start-JDPlatform',
        'Stop-JDPlatform',
        'Restart-JDPlatform',
        'Get-JDPlatformStatus',
        'Get-JDPlatformMetadata'
    )