<#
==============================================================================
JustDefenders©
==============================================================================
Work Package       : WP-PARTS-001
Production Revision: PR-001A (Revised)
Component          : Parts Domain Core
==============================================================================#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

class JDEvidence {
    [guid]$EvidenceId=[guid]::NewGuid()
    [string]$Source
    [string]$SourceType
    [double]$Confidence=1.0
    [bool] Validate(){ return -not [string]::IsNullOrWhiteSpace($this.Source) }
    [string] ToString(){ return "$($this.Source) [$($this.SourceType)]" }
}

class JDManufacturer {
    [guid]$ManufacturerId=[guid]::NewGuid()
    [string]$Name
    [string]$Country
    [bool] Validate(){ return -not [string]::IsNullOrWhiteSpace($this.Name) }
    [string] ToString(){ return $this.Name }
}

class JDBrand {
    [guid]$BrandId=[guid]::NewGuid()
    [JDManufacturer]$Manufacturer
    [string]$Name
    [string]$BrandType
    [bool] Validate(){
        return ($this.Manufacturer -ne $null) -and
               ($this.Manufacturer.Validate()) -and
               (-not [string]::IsNullOrWhiteSpace($this.Name))
    }
    [string] ToString(){
        if($this.Manufacturer){ return "$($this.Manufacturer.Name)/$($this.Name)" }
        return $this.Name
    }
}

function New-JDEvidence{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Source,
        [string]$SourceType="Unknown",
        [double]$Confidence=1.0
    )
    $o=[JDEvidence]::new()
    $o.Source=$Source
    $o.SourceType=$SourceType
    $o.Confidence=$Confidence
    if(-not $o.Validate()){ throw "Invalid evidence." }
    $o
}

function New-JDManufacturer{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [string]$Country=""
    )
    $o=[JDManufacturer]::new()
    $o.Name=$Name
    $o.Country=$Country
    if(-not $o.Validate()){ throw "Invalid manufacturer." }
    $o
}

function New-JDBrand{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][JDManufacturer]$Manufacturer,
        [string]$BrandType="OEM"
    )
    $o=[JDBrand]::new()
    $o.Name=$Name
    $o.BrandType=$BrandType
    $o.Manufacturer=$Manufacturer
    if(-not $o.Validate()){ throw "Invalid brand." }
    $o
}

Export-ModuleMember -Function New-JDEvidence,New-JDManufacturer,New-JDBrand
