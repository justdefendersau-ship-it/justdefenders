# Revised PR-001A

Tests use 'using module' because PowerShell classes used in parameter types must be available at parse time.