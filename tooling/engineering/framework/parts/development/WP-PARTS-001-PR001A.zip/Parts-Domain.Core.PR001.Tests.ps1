Import-Module .\Parts-Domain.Core.PR001.psm1 -Force

$e=[JDEvidence]::new()
$e.Source="Land Rover EPC"
$e.SourceType="OEM"

$m=[JDManufacturer]::new()
$m.Name="Land Rover"
$m.Country="United Kingdom"

$b=[JDBrand]::new()
$b.Name="Genuine Land Rover"
$b.BrandType="OEM"
$b.Manufacturer=$m

$e.Validate()
$m.Validate()
$b.Validate()

$e
$m
$b
