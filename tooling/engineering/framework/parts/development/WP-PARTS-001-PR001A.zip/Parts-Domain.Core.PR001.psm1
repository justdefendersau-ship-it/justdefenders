<#
==============================================================================
JustDefenders©
==============================================================================
Work Package       : WP-PARTS-001
Production Revision: PR-001A
Component          : Parts Domain Core
Timestamp          : 16 July 2026
File               : Parts-Domain.Core.PR001.psm1
==============================================================================#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

class JDEvidence {
    [guid]$EvidenceId
    [string]$Source
    [string]$SourceType
    [double]$Confidence = 1.0
    [bool]$Verified = $false
    [string]$VerifiedBy
    [Nullable[datetime]]$VerifiedDate
    [string]$ReferenceUrl
    [string]$Notes

    JDEvidence() { $this.EvidenceId = [guid]::NewGuid() }

    [bool] Validate() {
        return (-not [string]::IsNullOrWhiteSpace($this.Source))
    }

    [string] ToString() {
        return "{0} ({1:P0})" -f $this.Source,$this.Confidence
    }
}

class JDManufacturer {
    [guid]$ManufacturerId
    [string]$Name
    [string]$Country
    [string]$Website
    [string]$Status = "Active"

    JDManufacturer() { $this.ManufacturerId=[guid]::NewGuid() }

    [bool] Validate() {
        return (-not [string]::IsNullOrWhiteSpace($this.Name))
    }

    [string] ToString() { return $this.Name }
}

class JDBrand {
    [guid]$BrandId
    [JDManufacturer]$Manufacturer
    [string]$Name
    [string]$BrandType
    [string]$Status="Active"

    JDBrand(){ $this.BrandId=[guid]::NewGuid() }

    [bool] Validate() {
        return ($null -ne $this.Manufacturer -and
                $this.Manufacturer.Validate() -and
                -not [string]::IsNullOrWhiteSpace($this.Name))
    }

    [string] ToString() {
        if($this.Manufacturer){ return "$($this.Manufacturer.Name) / $($this.Name)" }
        return $this.Name
    }
}

Export-ModuleMember
