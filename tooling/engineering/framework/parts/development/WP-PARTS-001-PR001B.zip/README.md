# WP-PARTS-001 PR-001B

Adds:
- JDPart
- JDPartNumber
- New-JDPart
- New-JDPartNumber

Validation:
Import-Module .\Parts-Domain.Core.psm1 -Force
.\Parts-Domain.Core.PR001B.Tests.ps1
