<#
==============================================================================
JustDefenders©
==============================================================================
Timestamp          : 16 July 2026, 14:22
Work Package       : WP-PARTS-001
Production Revision: PR-001C
Component          : Parts Domain Core
Version            : 1.0.0-alpha3
File               : C:\dev\justdefenders\frontend\tooling\engineering\framework\parts\development\Parts-Domain.Core.psm1

Purpose:
    Complete replacement production module containing the Foundation,
    Canonical Identity and Compatibility domain objects.
==============================================================================
#>

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

class JDEvidence {
    [guid]$EvidenceId=[guid]::NewGuid()
    [string]$Source
    [string]$SourceType="Unknown"
    [double]$Confidence=1.0
    [bool] Validate(){ return -not [string]::IsNullOrWhiteSpace($this.Source) }
    [string] ToString(){ "$($this.Source) [$($this.Confidence)]" }
}

class JDManufacturer {
    [guid]$ManufacturerId=[guid]::NewGuid()
    [string]$Name
    [string]$Country
    [bool] Validate(){ return -not [string]::IsNullOrWhiteSpace($this.Name) }
    [string] ToString(){ $this.Name }
}

class JDBrand {
    [guid]$BrandId=[guid]::NewGuid()
    [object]$Manufacturer
    [string]$Name
    [string]$BrandType="OEM"
    [bool] Validate(){ return ($null -ne $this.Manufacturer) -and (-not [string]::IsNullOrWhiteSpace($this.Name)) }
    [string] ToString(){ $this.Name }
}

class JDPartNumber {
    [guid]$PartNumberId=[guid]::NewGuid()
    [string]$Number
    [string]$NumberType="OEM"
    [object]$Evidence
    [bool] Validate(){ return -not [string]::IsNullOrWhiteSpace($this.Number)}
    [string] ToString(){ "$($this.Number) [$($this.NumberType)]" }
}

class JDPart {
    [guid]$PartId=[guid]::NewGuid()
    [string]$CanonicalPartNumber
    [string]$Description
    [string]$Category="General"
    [string]$SubCategory=""
    [object]$Manufacturer
    [object]$Brand
    [System.Collections.Generic.List[object]]$PartNumbers
    JDPart(){ $this.PartNumbers=[System.Collections.Generic.List[object]]::new() }
    [void] AddPartNumber([object]$pn){ $this.PartNumbers.Add($pn) }
    [object] GetPrimaryPartNumber(){ if($this.PartNumbers.Count){$this.PartNumbers[0]} }
    [bool] Validate(){ return (-not [string]::IsNullOrWhiteSpace($this.CanonicalPartNumber)) -and (-not [string]::IsNullOrWhiteSpace($this.Description))}
    [string] ToString(){ "$($this.CanonicalPartNumber) - $($this.Description)"}
}

class JDCompatibility {
    [guid]$CompatibilityId=[guid]::NewGuid()
    [object]$Part
    [string]$VehicleModel
    [int]$YearFrom
    [int]$YearTo
    [string]$Engine
    [string]$Gearbox
    [string]$Market="AU"
    [int]$Confidence=100
    [object]$Evidence
    [bool] Validate(){
        if($null -eq $this.Part){return $false}
        if([string]::IsNullOrWhiteSpace($this.VehicleModel)){return $false}
        if($this.YearTo -and $this.YearTo -lt $this.YearFrom){return $false}
        return ($this.Confidence -ge 0 -and $this.Confidence -le 100)
    }
    [string] ToString(){ "$($this.VehicleModel) $($this.Engine) [$($this.Confidence)%]" }
}

function New-JDEvidence{param([Parameter(Mandatory)][string]$Source,[string]$SourceType="Unknown",[double]$Confidence=1.0)
$o=[JDEvidence]::new();$o.Source=$Source;$o.SourceType=$SourceType;$o.Confidence=$Confidence;if(!$o.Validate()){throw};$o}
function New-JDManufacturer{param([Parameter(Mandatory)][string]$Name,[string]$Country="")
$o=[JDManufacturer]::new();$o.Name=$Name;$o.Country=$Country;if(!$o.Validate()){throw};$o}
function New-JDBrand{param([Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)][object]$Manufacturer,[string]$BrandType="OEM")
$o=[JDBrand]::new();$o.Name=$Name;$o.Manufacturer=$Manufacturer;$o.BrandType=$BrandType;if(!$o.Validate()){throw};$o}
function New-JDPart{param([Parameter(Mandatory)][string]$CanonicalPartNumber,[Parameter(Mandatory)][string]$Description)
$o=[JDPart]::new();$o.CanonicalPartNumber=$CanonicalPartNumber;$o.Description=$Description;if(!$o.Validate()){throw};$o}
function New-JDPartNumber{param([Parameter(Mandatory)][string]$Number,[string]$NumberType="OEM",[object]$Evidence)
$o=[JDPartNumber]::new();$o.Number=$Number;$o.NumberType=$NumberType;$o.Evidence=$Evidence;if(!$o.Validate()){throw};$o}
function New-JDCompatibility{
param([Parameter(Mandatory)][object]$Part,[Parameter(Mandatory)][string]$VehicleModel,[int]$YearFrom,[int]$YearTo,[string]$Engine,[string]$Gearbox,[string]$Market="AU",[int]$Confidence=100,[object]$Evidence)
$o=[JDCompatibility]::new();$o.Part=$Part;$o.VehicleModel=$VehicleModel;$o.YearFrom=$YearFrom;$o.YearTo=$YearTo;$o.Engine=$Engine;$o.Gearbox=$Gearbox;$o.Market=$Market;$o.Confidence=$Confidence;$o.Evidence=$Evidence;if(!$o.Validate()){throw};$o}

Export-ModuleMember -Function New-JDEvidence,New-JDManufacturer,New-JDBrand,New-JDPart,New-JDPartNumber,New-JDCompatibility
