# PR-001C Complete replacement module
Replace the existing Parts-Domain.Core.psm1 with this version, then run Parts-Domain.Core.Tests.