<#
==============================================================================
JustDefenders©
==============================================================================
Timestamp          : 16 July 2026, 14:22
Work Package       : WP-PARTS-001
Production Revision: PR-001C
Component          : Compatibility Domain
File               : C:\dev\justdefenders\frontend\tooling\engineering\framework\parts\development\Parts-Domain.Core.psm1
==============================================================================
#>

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

# Existing PR-001C additions only. Merge into existing module.

class JDCompatibility {
    [guid]$CompatibilityId=[guid]::NewGuid()
    [object]$Part
    [string]$VehicleModel
    [string]$VehicleSeries
    [int]$YearFrom
    [int]$YearTo
    [string]$Engine
    [string]$Gearbox
    [string]$TransferCase
    [string]$FrontAxle
    [string]$RearAxle
    [string]$Market="AU"
    [string]$FitmentType="Direct"
    [int]$Confidence=100
    [object]$Evidence
    [string]$Notes

    [bool]Validate(){
        if($null -eq $this.Part){ return $false }
        if([string]::IsNullOrWhiteSpace($this.VehicleModel)){ return $false }
        if($this.YearTo -and $this.YearTo -lt $this.YearFrom){ return $false }
        if($this.Confidence -lt 0 -or $this.Confidence -gt 100){ return $false }
        return $true
    }

    [string]ToString(){
        return "{0} {1}-{2} ({3}%)" -f $this.VehicleModel,$this.YearFrom,$this.YearTo,$this.Confidence
    }
}

function New-JDCompatibility{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Part,
        [Parameter(Mandatory)][string]$VehicleModel,
        [int]$YearFrom,
        [int]$YearTo,
        [string]$Engine,
        [string]$Gearbox,
        [string]$Market="AU",
        [int]$Confidence=100,
        [object]$Evidence,
        [string]$Notes=""
    )

    $c=[JDCompatibility]::new()
    $c.Part=$Part
    $c.VehicleModel=$VehicleModel
    $c.YearFrom=$YearFrom
    $c.YearTo=$YearTo
    $c.Engine=$Engine
    $c.Gearbox=$Gearbox
    $c.Market=$Market
    $c.Confidence=$Confidence
    $c.Evidence=$Evidence
    $c.Notes=$Notes

    if(-not $c.Validate()){ throw "Invalid JDCompatibility." }
    $c
}

Export-ModuleMember -Function New-JDCompatibility
