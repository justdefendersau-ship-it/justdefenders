WP-PARTS-001 PR-001C

This revision adds:
- JDCompatibility
- New-JDCompatibility

Merge the module contents into the existing Parts-Domain.Core.psm1 before testing.
