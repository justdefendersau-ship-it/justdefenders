WP-JDEF-001B PR-002 Deployment

1. Replace the existing Runtime-Component.PR002.psm1 with the enclosed version.
2. Confirm there is NO 'using module' statement in the file.
3. Run Runtime-Component.PR002.Tests.ps1.
4. If successful, commit PR-002.
