WP-JDEF-001B PR-006

1. Copy Runtime-Publisher.PR006.psm1 into the runtime development folder.
2. Run Runtime-Publisher.PR006.Tests.ps1.
3. Verify Published=True and a PublishedAt timestamp is present.
